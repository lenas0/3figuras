// Escena principal
const entorno = new THREE.Scene();
const camaraGeneral = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

const renderPrincipal = new THREE.WebGLRenderer();
renderPrincipal.setSize(window.innerWidth, window.innerHeight * 0.6);
document.getElementById('contenedor-figuras').appendChild(renderPrincipal.domElement);

// Geometrías
const formaPrisma = new THREE.BoxGeometry(1, 1, 1);
const formaTubo = new THREE.CylinderGeometry(0.5, 0.5, 1, 32);
const formaOrbe = new THREE.SphereGeometry(0.7, 32, 16);

// Materiales pastel
const tonoPrisma = new THREE.MeshBasicMaterial({ color: 0xA7C7E7 });   // azul pastel
const tonoTubo = new THREE.MeshBasicMaterial({ color: 0xF9C5D5 });     // rosa suave
const tonoOrbe = new THREE.MeshBasicMaterial({ color: 0xB9F3FC });     // celeste pastel

// Figuras principales
const prisma = new THREE.Mesh(formaPrisma, tonoPrisma);
const tubo = new THREE.Mesh(formaTubo, tonoTubo);
const orbe = new THREE.Mesh(formaOrbe, tonoOrbe);

prisma.position.x = -2;
tubo.position.x = 0;
orbe.position.x = 2;

entorno.add(prisma);
entorno.add(tubo);
entorno.add(orbe);

camaraGeneral.position.z = 5;

// Renderers de las tarjetas
const renderPrisma = new THREE.WebGLRenderer();
renderPrisma.setSize(200, 200);
document.getElementById('tarjeta-prisma').appendChild(renderPrisma.domElement);

const renderTubo = new THREE.WebGLRenderer();
renderTubo.setSize(200, 200);
document.getElementById('tarjeta-tubo').appendChild(renderTubo.domElement);

const renderOrbe = new THREE.WebGLRenderer();
renderOrbe.setSize(200, 200);
document.getElementById('tarjeta-orbe').appendChild(renderOrbe.domElement);

// Escenas de las tarjetas
const entornoPrisma = new THREE.Scene();
const entornoTubo = new THREE.Scene();
const entornoOrbe = new THREE.Scene();

// Figuras en las tarjetas
const prismaMini = new THREE.Mesh(formaPrisma, tonoPrisma);
const tuboMini = new THREE.Mesh(formaTubo, tonoTubo);
const orbeMini = new THREE.Mesh(formaOrbe, tonoOrbe);

entornoPrisma.add(prismaMini);
entornoTubo.add(tuboMini);
entornoOrbe.add(orbeMini);

// Cámara de tarjetas
const camaraMini = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
camaraMini.position.z = 3;

// Animación
function rotarFiguras() {
  requestAnimationFrame(rotarFiguras);

  prisma.rotation.x += 0.01;
  prisma.rotation.y += 0.01;
  prismaMini.rotation.x += 0.01;
  prismaMini.rotation.y += 0.01;

  tubo.rotation.x += 0.01;
  tubo.rotation.y += 0.01;
  tuboMini.rotation.x += 0.01;
  tuboMini.rotation.y += 0.01;

  orbe.rotation.x += 0.01;
  orbe.rotation.y += 0.01;
  orbeMini.rotation.x += 0.01;
  orbeMini.rotation.y += 0.01;

  renderPrincipal.render(entorno, camaraGeneral);
  renderPrisma.render(entornoPrisma, camaraMini);
  renderTubo.render(entornoTubo, camaraMini);
  renderOrbe.render(entornoOrbe, camaraMini);
}

rotarFiguras();

// Adaptación al tamaño de pantalla
window.addEventListener('resize', () => {
  camaraGeneral.aspect = window.innerWidth / (window.innerHeight * 0.6);
  camaraGeneral.updateProjectionMatrix();
  renderPrincipal.setSize(window.innerWidth, window.innerHeight * 0.6);
});
